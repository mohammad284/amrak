<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following notifications lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these notifications lines according to your application's requirements.
    |
    */

    'failed' => 'بيانات تسجيل الدخول غير صحيحة.',
    'throttle' => 'الكثير من المحاولات الخاطئة الرجاء المحاولة بعد  :seconds seconds.',
    'email'=>'البريد الإلكتروني',

];
